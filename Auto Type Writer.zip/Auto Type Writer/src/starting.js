const { tokenCheck } = require('./utils/functions/tokenCheck');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function starting() {
    console.log("Token is valid!");
    await sleep(3000);
    console.clear()
    console.log("Tokenler Checkleniyor... (20sn)")
    await tokenCheck();
    let token = require('./utils/functions/tokenCheck').activeArr;
    console.log("Token Sayısı: " + token.length);
    require('./utils/index')
}

starting();